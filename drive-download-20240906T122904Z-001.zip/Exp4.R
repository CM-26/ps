#1.The probability distribution of X, the number of imperfections per 10 meters of a synthetic fabric in continuous 
#rolls of uniform width, is given as

#  x   0   1     2     3     4
#p(x) 0.41 0.37 0.16 0.05 0.01


x<- c(0,1,2,3,4)
p<- c(0.41,0.37,0.16,0.05,0.01)

sum(x*p)

weighted.mean(x,p)

(x %*% p)

# --------------------------------------------------------------------------------------------------------------------------------------------

#2.The time T, in days, required for the completion of a contracted project is a random variable with probability density function 
#f(t) = 0.1 e(-0.1t) for t > 0 and 0 otherwise. Find the expected value of T.Use function integrate( ) to find the expected value of 
#continuous random variable T.

# when dealing with discrete values use sum , when dealing with continous values use integration.

F<- function(t){t * 0.1 * exp(-0.1*t)}

A<- integrate(F,0,Inf)

A  # if we print alone A then the absolute error also gets printed.

print(A $ value)

# --------------------------------------------------------------------------------------------------------------------------------------------

#3.A bookstore purchases three copies of a book at $6.00 each and sells them for $12.00 each. Unsold copies are 
#returned for $2.00 each. Let X = {number of copies sold} and Y = {net revenue}. If the probability mass function of X is
#   x 0    1   2   3
#p(x) 0.1 0.2 0.2 0.5

#net revenue = profit 

x<- c(0,1,2,3)
p<- c(0.1,0.2,0.2,0.5)


# y = -(3x6) + 12x + 2(3-x)  ==> y= 10x -12

y<-(10*x - 12)
a<-sum(y*p)
a

# --------------------------------------------------------------------------------------------------------------------------------------------

##4.Find the first and second moments about the origin of the random variable X with probability density function f(x) = 0.5e-|x|, 1 < x < 10 
# and 0 otherwise.Further use the results to find Mean and Variance.(kth moment = E(Xk), Mean = first moment and Variance = second moment – Mean2

#first moment
# E(x) = integration(1,10) x*f(x) d(x)
#second moment
# E2(x) = integration(1,10) x*x*f(x) d(x)


f<- function(x){x*0.5*exp(-1*abs(x))}
f2<- function(x){x*x*0.5*exp(-1*abs(x))}

a<-integrate(f,lower = 1,upper = 10)
b<-integrate(f2,lower = 1,upper = 10)

fm <- a$value
sm <- b$value

var <- (sm - fm^2)

print(paste("first mean ",fm ))
print(paste("second mean ",sm))
print(paste("variance ",var))



# --------------------------------------------------------------------------------------------------------------------------------------------

#5.Let X be a geometric random variable with probability distribution 𝑓(𝑥)=3/4(1/4)^(𝑥−1),𝑥=1,2,3,..Write a function to find the probability 
#distribution of the random variable Y = X^2 and find probability of Y for X = 3. Further, use it to find the expected value and variance of 
#Y for X = 1,2,3,4,5.


# we cannot use integrate(f*x) in integration but can use sum(y*f) in case of discrete values.


f<- function(x){x*((3/4)*(1/4)^(x-1))}
f2<- function(x){x*((3/4)*(1/4)^((y^ 1/2)-1))}


x <- 3
y <- x^2
f2(y)


x <- c(1,2,3,4,5)
y <- x^2
y


p<-f2(y)
p

exp_val <- sum(y*p)
exp_val

#var

Ex <- sum(y*p)
E2x <- sum((y^2)*p)
var <- E2x - (Ex^2)
var

#--------------------------------------------------------------------------------
f3<-function(x) (3/4)*(1/4^(x-1))
y3<-function(x) (x^2)

x<-c(1,2,3,4,5)
f3(x)
distr<-data.frame(x,f3(x))
distr
distr<-data.frame(f3(x))
distr
ans=f3(1)*y3(1)+f3(2)*y3(2)+f3(3)*y3(3)+f3(4)*y3(4)+f3(5)*y3(5)
ans
ans3=f3(3)*y3(3)
ans3
x<-c(1,2,3,4,5)
f3(x)
#mean
mean<-weighted.mean(x,f3(x))
mean
#variance
var<-ans-mean^2
var