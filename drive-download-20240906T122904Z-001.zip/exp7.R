#(1) Use the rt(n,df) function in r to investigate the t-distribution for n = 100 and df = n - 1 and plot
#the histogram for the same. df- degree of freedom.
# histogram would be different as the value of the n is different.
# r starting comand for random

n<-c(100)
df<-n-1

sample<- rt(n,df)

sample

hist(sample)



#-------------------------------------------------------------------------------
#(2) Use the rchisq(n; df) function in r to investigate the chi-square distribution with n = 100 and
#df = 2; 10; 25.


n<-c(100)
df<-c(2,10,25)
c1<- rchisq(n,df[1])
c2<- rchisq(n,df[2])
c3<- rchisq(n,df[3])
c1
c2
c3

#-------------------------------------------------------------------------------
#(3) Generate a vector of 100 values between -6 and 6. Use the dt() function in r to  nd the values of a
#t-distribution given a random variable x and degrees of freedom 1,4,10,30. Using these values plot
#the density function for students t-distribution with degrees of freedom 30. Also shows a comparison
#of probability density functions having diferent degrees of freedom (1,4,10,30).


s<- seq(from=-6, to=6, length = 100)
df<-c(1,4,10,30)

t_1<-dt(s,df[1])
t_2<-dt(s,df[2])
t_3<-dt(s,df[3])
t_4<-dt(s,df[4])


plot(s,t_4,type="l")


# for all graphs

clr<-c("green","red","brown","black")
for (i in 1:4) {
  lines(s,dt(s,df[i]),col=clr[i],type="l")
  
}


#-------------------------------------------------------------------------------
#(4) Write a r-code
#(i) To find the 95th percentile of the F-distribution with (10; 20) degrees of freedom.
#(ii) To calculate the area under the curve for the interval [0; 1:5] and the interval [1:5;+1) of
#a F-curve with v1 = 10 and v2 = 20 (USE pf()).
#(iii) To calculate the quantile for a given area (= probability) under the curve for a F-curve
#with v1 = 10 and v2 = 20 that corresponds to q = 0:25; 0:5; 0:75 and 0:999. (use the qf())
#(iv) To generate 1000 random values from the F-distribution with v1 = 10 and v2 = 20 (use rf())and plot a histogram.


#(i)

df1<-10
df2<-20
p<-0.95
qf(p,df1,df2)


#(ii)

x<-1.5
df1<-10
df2<-20
a1<-pf(x,df1,df2,lower.tail = TRUE)  # 1.5 being the mid point  t,f for left and right area
a2<-pf(x,df1,df2,lower.tail = FALSE)
a1
a2
a1+a2

#(iii) lower.tail = TRUE is default

df1<-10
df2<-20
p<-c(0.25,0.5,0.75,0.999)

a1<-qf(p[1],df1,df2,lower.tail = TRUE)
a2<-qf(p[2],df1,df2)
a3<-qf(p[3],df1,df2)
a4<-qf(p[4],df1,df2)


a1
a2
a3
a4


#(iv)

x<-rf(1000,10,20)

hist(x,freq=FALSE,xlim = c(0,3),ylim=c(0,1))

#modification
hist(x,freq=FALSE,xlim = c(0,3),ylim=c(0,1),breaks="scott")

#imp area question 

