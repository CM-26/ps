#1.Consider that X is the time (in minutes) that a person has to wait in order to take a flight. If each flight takes off each hour X ~ U(0, 60). 
#Find the probability that
#(a) waiting time is more than 45 minutes, and
#(b) waiting time lies between 20 and 30 minutes.

dunif(10,0,60)  # p(X<=10)

#a)
punif(45,0,60,lower.tail = FALSE)  #p(X>=10)

#b)
punif(20,0,60,lower.tail = FALSE)-punif(30,0,60,lower.tail = FALSE)


#------------------------------------------------------------------------------------------------------------------------------------------------
#2.The time (in hours) required to repair a machine is an exponential distributed random variable with parameter λ = 1/2.
#(a) Find the value of density function at x = 3.
#(b) Plot the graph of exponential probability distribution for 0 ≤ x ≤ 5.
#(c) Find the probability that a repair time takes at most 3 hours.
#(d) Plot the graph of cumulative exponential probabilities for 0 ≤ x ≤ 5.
#(e) Simulate 1000 exponential distributed random numbers with λ = ½ and plot the simulated data.

#a). if P(X=x) dexp(x,lambda)    ,, P(X<=x) dexp(x,lambda)
dexp(3,0.5)   


#b). 
x<-seq(0,5,0.5)

#x<-c(0,1,2,3,4,5)
plot(x,dexp(x,1))



#c). *****

pexp(0.5,3)



#d).
x<-seq(0,5,0.5)

#x<-c(0,1,2,3,4,5)
plot(x,dexp(x,1/2))



#e).


y<-rexp(1000,0.5)

plot(density(y),1000)   # x axis - simulated  ,, y axis - density



#------------------------------------------------------------------------------------------------------------------------------------------------
#3.The lifetime of certain equipment is described by a random variable X that follows Gamma distribution with parameters α = 2 and β = 1/3.
#(a) Find the probability that the lifetime of equipment is (i) 3 units of time, and (ii) at least 1 unit of time.
#(b) What is the value of c, if P(X ≤ c) ≥ 0.70? (Hint: try quantile function qgamma())



# a(i)
#if we use scale b becomes 3 instead of 1/3 dgamma(3,shape=2,scale=1/3)

dgamma(3,shape=2,scale=1/3)



#a(ii)

pgamma(1,shape=2,scale=1/3,lower.tail = FALSE)

1-pgamma(1,shape=2,scale=1/3)


#b

qgamma(0.70,shape=2,scale=1/3)


