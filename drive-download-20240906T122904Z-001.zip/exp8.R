#This file is submitted by Nitin_Kumar , 102017094 , 3CS5


data<-read.csv(file.choose())

#dimensions
dim(data)
#rows and columns
ncol(data)
nrow(data)

head(data,10)


#mean
mean(data$Wall.Thickness)
#histogram 
h<-hist(data$Wall.Thickness)
abline(v=12.8,col='blue')

#q2

#a


s10<-c()
n<-9000
for (i in 1:9000) {
  s10[i]=mean(sample(data$Wall.Thickness,10,replace=FALSE))
}
hist(s10)


mean(s10)
abline(v=mean(s10),col='red')
abline(v=12.8,col='blue')


#b for 50
s10<-c()
n<-9000
for (i in 1:9000) {
  s10[i]=mean(sample(data$Wall.Thickness,50,replace=FALSE))
}
hist(s10)


#for 500
s10<-c()
n<-9000
for (i in 1:9000) {
  s10[i]=mean(sample(data$Wall.Thickness,500,replace=FALSE))
}
hist(s10)

#for 5000
s10<-c()
n<-9000
for (i in 1:9000) {
  s10[i]=mean(sample(data$Wall.Thickness,5000,replace=FALSE))
}
hist(s10)

