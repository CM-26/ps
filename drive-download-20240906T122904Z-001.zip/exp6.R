#This file is submitted by Nitin_Kumar , 102017094 , 3CS5
#Assgnment 6

#Q1

#(i) check that it is a joint density function or not? (Use integral2())
#(ii)Find marginal distribution g(x) at x = 1.
#(iii) Find the marginal distribution h(y) at y = 0:
#(iv) Find the expected value of g(x; y) = xy.


#(i)


f<-function(x,y){2*(2*x + 3*y)/5}

a<-integral2(f,xmin=0,xmax = 1,ymin = 0,ymax = 1)

a$Q

#(ii)

# we can change fn to f<-function(y)f(1,y)  

f1<-function(y){
  
  ff1<-f(1,y)
  }

a<-integral(f1,0,1)
a


#(iii)

f2<-function(x){
  ff2<-f(x,0)
}

a<-integral(f2,0,1)
a

#(iv)


f_xy<-function(x,y){
  
f(x,y)*x*y
}

a<-integral2(f_xy,xmin=0,xmax = 1,ymin = 0,ymax = 1)
a$Q


#---------------------------------------------------------------------------------


#Q2 

#(i) display the joint mass function in rectangular (matrix) form.
#(ii) check that it is joint mass function or not? (use: Sum())
#(iii) Find the marginal distribution g(x) for x = 0; 1; 2; 3. (Use:apply())
#(iv) Find the marginal distribution h(y) for y = 0; 1; 2. (Use:apply())
#(v) find the conditional probability at x = 0 given y = 1.   ans 0.1
#(vi) find E(x);E(y);E(xy); V ar(x); V ar(y);Cov(x; y) and its correlation coefcient.  ans cov=-0.1333
 

f<-function(x,y){(x+y)/30
}

#a
m=matrix(c(f(0,0:2),f(1,0:2),f(2,0:2),f(3,0:2)), nrow=4,ncol=3,byrow = TRUE)
m

#b
if(sum(m)==1){
  print("It is joint mass function")
}else{
  print("It is not joint mass function")
}

#c

gx<-apply(m,1,sum)
gx

#d
hy<-apply(m,2,sum)
hy


#e
ans=m[1,2]/hy[2]
ans

#f
x<-c(0,1,2,3)
y<-c(0,1,2)

# E(x),E(y)
meanx=sum(x*gx)
meany=sum(y*hy)
meanx
meany

# Var(x),Var(y)
varx=sum(x*x*gx)-meanx^2
vary=sum(y*y*hy)-meany^2
varx
vary


# E(x,y) , Cov(x,y),correlation coefficient

f1<-function(x,y){
  x*y*f(x,y)
}

m1=matrix(c(f1(0,0:2),f1(1,0:2),f1(2,0:2),f1(3,0:2)),nrow=4,ncol=3,byrow = TRUE)
exy=sum(m1)
exy

covxy=exy-meanx*meany
covxy

corr=covxy/sqrt(varx*vary)
corr






